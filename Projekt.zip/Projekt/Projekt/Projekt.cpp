﻿
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <locale.h>
#include <cctype>
#include <ctime>
#include <cstdlib>
using namespace std;

const int plansza_wiersze = 4;
const int plansza_kolumny = 4;
struct Gracze {
	char gracz_bialy[30];
	char gracz_czarny[30];
	bool tura;
};
struct Pozycje {
	char poz_poczX;
	int  poz_poczY;
	char poz_konX;
	int  poz_konY;
};
//Wczytanie imion graczy
void wczytajGraczy(Gracze& gracze) {
	cout << "Podaj imie pierwszego gracza " << endl;
	cin >> gracze.gracz_bialy;
	cout << "Podaj imie drugiego gracza " << endl;
	cin >> gracze.gracz_czarny;
	gracze.tura = true;
}

//Wyświetlenie imion graczy 
void wypiszGraczy(Gracze& gracze) {
	cout <<  "Gracz pionkami bialymi : " << gracze.gracz_bialy << endl;
	cout << "Gracz pionkami czarnymi : " << gracze.gracz_czarny << endl;
}
//wyglad planszy poczatkowej
void wygladPlanszy(char plansza[plansza_wiersze][plansza_kolumny]) {
	plansza[0][0] = 'c'; plansza[0][1] = 'c'; plansza[0][2] = 'c'; plansza[0][3] = 'c';
	plansza[1][0] = ' '; plansza[1][1] = ' '; plansza[1][2] = ' '; plansza[1][3] = ' ';
	plansza[2][0] = ' '; plansza[2][1] = ' '; plansza[2][2] = ' '; plansza[2][3] = ' ';
	plansza[3][0] = 'b'; plansza[3][1] = 'b'; plansza[3][2] = 'b'; plansza[3][3] = 'b';
}
//wyswietlenie planszy
void wyswietlPlansze(char plansza[plansza_wiersze][plansza_kolumny]) {
	int asci = 65;
	int liczba = 4;
	int a = 1;
	cout << "  ";
	wcout << L"\u2554";
	wcout << L"\u2550";
	wcout << L"\u2566";
	wcout << L"\u2550";
	wcout << L"\u2566";
	wcout << L"\u2550";
	wcout << L"\u2566";
	wcout << L"\u2550";
	wcout << L"\u2557";
	cout << endl;
	for (int i = 0; i < plansza_wiersze; i++) {
		cout << liczba << ' ';
		liczba--;
		wcout << L"\u2551";
		for (int j = 0; j < plansza_kolumny; j++) {
			if (a != 4 && a != 8 && a != 12 && a != 16) {
				wcout << plansza[i][j] << L"\u256C";
			}
			else {
				wcout << plansza[i][j] << L"\u2551";
			}
			a++;

		}
		cout << endl;
	}
	cout << "  ";
	wcout << L"\u255A";
	wcout << L"\u2550";
	wcout << L"\u2569";
	wcout << L"\u2550";
	wcout << L"\u2569";
	wcout << L"\u2550";
	wcout << L"\u2569";
	wcout << L"\u2550";
	wcout << L"\u255D";
	cout << endl;
	cout<< "  ";
	for (int i = 0; i < plansza_wiersze; i++) {
		cout << " " << char(asci);
		asci++;
	}
}
bool walidacjaWspolrzednych(char kolumna, int wiersz) {
	kolumna = tolower(kolumna);
	if (kolumna >= 'A' && kolumna <= 'D' || kolumna >= 'a' && kolumna <= 'd' && wiersz >= 1 && wiersz <= 4) {
		return true; 
	}
	return false; 
}


void pobierzPozycje(Pozycje& pozycje, char plansza[plansza_wiersze][plansza_kolumny], char pionek) {
	do {
		cout << "Podaj pozycje poczatkowa twojego pionka (A-D): ";
		cin >> pozycje.poz_poczX;

		cout << "Podaj pozycje poczatkowa twojego pionka (4-1): ";
		cin >> pozycje.poz_poczY;

		pozycje.poz_poczX = tolower(pozycje.poz_poczX);

		int x = pozycje.poz_poczX - 'a';
		int y = 4 - pozycje.poz_poczY;
		if (plansza[y][x] == 'b' || plansza[y][x] == 'c') {
			if (plansza[y][x] == pionek) {
				if (walidacjaWspolrzednych(pozycje.poz_poczX, pozycje.poz_poczY)) {
					break;
				}
				else {
					cout << "Wyszedłeś poza planszę!" << endl;
				}
			}
			else {
				cout << "To nie jest twoj pionek!" << endl; 
			}
		}
		else {
			cout << "Nie ma tam pionka!" << endl;
		}
	} while (true);

	cout << "Twoja pozycja to: " << pozycje.poz_poczX << pozycje.poz_poczY << endl;
}
void podajRuch(Pozycje& pozycje) {
	do {
		cout << "Gdzie chcesz ruszyc pionka (A-D)? ";
		cin >> pozycje.poz_konX;

		cout << "Gdzie chcesz ruszyc pionka (4-1)? ";
		cin >> pozycje.poz_konY;

		pozycje.poz_konX = tolower(pozycje.poz_konX);

		if (walidacjaWspolrzednych(pozycje.poz_konX, pozycje.poz_konY)) {
			break; 
		}
		else {
			cout << "Wyszedles poza plansze\n";
		}
	} while (true);

	cout << "Wykonujesz ruch na: " << pozycje.poz_konX << pozycje.poz_konY << endl;
}
// GRACZ VS GRACZ
bool wykonajBicie(int pocz_x, int pocz_y, int ruch_x, int ruch_y, char plansza[plansza_wiersze][plansza_kolumny], char pionek) {
	char przeciwnik;
	if (pionek == 'b') {
		przeciwnik = 'c';
	}
	else {
		przeciwnik = 'b';
	}

	// Ruch w prawo
	if (ruch_x > pocz_x) {
		if (plansza[pocz_y][pocz_x + 1] == pionek) {
			if (plansza[ruch_y][ruch_x] == ' ') {
				if (ruch_x + 1 < plansza_kolumny && plansza[ruch_y][ruch_x + 1] == przeciwnik) {
					plansza[pocz_y][pocz_x] = ' ';
					plansza[ruch_y][ruch_x + 1] = pionek;
					return true;
				}
			}
		}
	}

	// Ruch w lewo
	if (ruch_x < pocz_x) {
		if (plansza[pocz_y][pocz_x - 1] == pionek) {
			if (plansza[ruch_y][ruch_x] == ' ') {
				if (ruch_x - 1 >= 0 && plansza[ruch_y][ruch_x - 1] == przeciwnik) {
					plansza[pocz_y][pocz_x] = ' ';
					plansza[ruch_y][ruch_x - 1] = pionek;
					return true;
				}
			}
		}
	}

	// Ruch w dół
	if (ruch_y > pocz_y) {
		if (plansza[pocz_y + 1][pocz_x] == pionek) {
			if (plansza[ruch_y][ruch_x] == ' ') {
				if (ruch_y + 1 < plansza_wiersze && plansza[ruch_y + 1][ruch_x] == przeciwnik) {
					plansza[pocz_y][pocz_x] = ' ';
					plansza[ruch_y + 1][ruch_x] = pionek;
					return true;
				}
			}
		}
	}

	// Ruch w górę
	if (ruch_y < pocz_y) {
		if (plansza[pocz_y - 1][pocz_x] == pionek) {
			if (plansza[ruch_y][ruch_x] == ' ') {
				if (ruch_y - 1 >= 0 && plansza[ruch_y - 1][ruch_x] == przeciwnik) {
					plansza[pocz_y][pocz_x] = ' ';
					plansza[ruch_y - 1][ruch_x] = pionek;
					return true;
				}
			}
		}
	}

	return false;
}
bool wygrana(char plansza[plansza_wiersze][plansza_kolumny], int licznikc, int licznikb) {

	for (int i = 0; i < plansza_wiersze; i++) {
		for (int j = 0; j < plansza_kolumny; j++) {
			if (plansza[i][j] == 'c') {
				licznikc++;
			}
			if (plansza[i][j] == 'b') {
				licznikb++;
			}
		}
	}

	if (licznikc == 0) {
		return true;
	}
	if (licznikb == 0) {
		return true;
	}
	return false;
}
bool wygranaZablokowanie(int pocz_x, int pocz_y, int ruch_x, int ruch_y, char plansza[plansza_wiersze][plansza_kolumny], char pionek) {
	char przeciwnik;
	if (pionek == 'b') {
		przeciwnik = 'c';
	}
	else {
		przeciwnik = 'b';
	}


	// Ruch w prawo
	if (ruch_x > pocz_x) {
		if (plansza[pocz_y][pocz_x + 1] == przeciwnik) {
			return true;
		}
	}

	// Ruch w lewo
	if (ruch_x < pocz_x) {
		if (plansza[pocz_y][pocz_x - 1] == przeciwnik) {
			return true;
		}
	}

	// Ruch w dół
	if (ruch_y > pocz_y) {
		if (plansza[pocz_y + 1][pocz_x] == przeciwnik) {
			return true;
		}
	}

	// Ruch w górę
	if (ruch_y < pocz_y) {
		if (plansza[pocz_y - 1][pocz_x] == przeciwnik) {
			return true;
		}
	}

	return false;
}
bool zwyklyRuch(int pocz_x, int pocz_y, int ruch_x, int ruch_y, char plansza[plansza_wiersze][plansza_kolumny], char pionek) {
	if (plansza[ruch_y][ruch_x] == ' ') {  
		plansza[ruch_y][ruch_x] = pionek;  
		plansza[pocz_y][pocz_x] = ' ';     
		return true;
	}
	return false;
}
void wykonajRuch(Pozycje& pozycje, char plansza[plansza_wiersze][plansza_kolumny], char pionek) {
    int pocz_x = pozycje.poz_poczX - 'a';
    int pocz_y = 4 - pozycje.poz_poczY;

    int ruch_x = pozycje.poz_konX - 'a';
    int ruch_y = 4 - pozycje.poz_konY;
	 
    if (wygranaZablokowanie(pocz_x, pocz_y, ruch_x, ruch_y, plansza, pionek)) {
        system("cls");
        cout << "Gracz " << pionek << " jest zablokowany";
        char przeciwnik;
        if (pionek == 'b') {
            przeciwnik = 'c';
        }
        else {
            przeciwnik = 'b';
        }
        cout << "WYGRANA " << przeciwnik;
        exit(0);
    }

    int roznica_x = abs(ruch_x - pocz_x);
    int roznica_y = abs(ruch_y - pocz_y);

    bool bicie = wykonajBicie(pocz_x, pocz_y, ruch_x, ruch_y, plansza, pionek);
    if (bicie) {
        return;
    }

    while (!(roznica_x <= 1 && roznica_y <= 1)) {
        cout << "Nie mozesz sie ruszac o dwa pola do przodu!" << endl;
        cout << "Podaj nowy ruch: ";
        cin >> pozycje.poz_poczX >> pozycje.poz_poczY >> pozycje.poz_konX >> pozycje.poz_konY;

        pocz_x = pozycje.poz_poczX - 'a';
        pocz_y = 4 - pozycje.poz_poczY;

        ruch_x = pozycje.poz_konX - 'a';
        ruch_y = 4 - pozycje.poz_konY;

        roznica_x = abs(ruch_x - pocz_x);
        roznica_y = abs(ruch_y - pocz_y);
    }

    zwyklyRuch(pocz_x, pocz_y, ruch_x, ruch_y, plansza, pionek);
}

// 1VS1 Z BOTEM
void obslugaBota(Pozycje& pozycje, char plansza[plansza_wiersze][plansza_kolumny]) {
	srand(time(0)); 
	bool wykonanoRuch = false;
	while (!wykonanoRuch) {
		//Sprawdzamy bicie dla kazdego pionka
		bool moznaZbic = false;  
		for (int i = 0; i < plansza_wiersze; i++) {
			for (int j = 0; j < plansza_kolumny; j++) {
				if (plansza[i][j] == 'b') {  
					// Bicie w prawo
					if (j + 3 < plansza_kolumny && plansza[i][j + 1] == 'b' && plansza[i][j + 2] == ' ' && plansza[i][j + 3] == 'c') {
						plansza[i][j] = ' '; 
						plansza[i][j + 3] = 'b'; 
						wykonanoRuch = true;
						moznaZbic = true;  
						break;
					}
					// Bicie w lewo
					else if (j - 3 >= 0 && plansza[i][j - 1] == 'b' && plansza[i][j - 2] == ' ' && plansza[i][j - 3] == 'c') {
						plansza[i][j] = ' '; 
						plansza[i][j - 3] = 'b';  
						wykonanoRuch = true;
						moznaZbic = true; 
						break;
					}
					// Bicie w górę
					else if (i - 3 >= 0 && plansza[i - 1][j] == 'b' && plansza[i - 2][j] == ' ' && plansza[i - 3][j] == 'c') {
						plansza[i][j] = ' ';
						plansza[i - 3][j] = 'b';
						wykonanoRuch = true;
						moznaZbic = true;  
						break;
					}
					// Bicie w dół
					else if (i + 3 < plansza_wiersze && plansza[i + 1][j] == 'b' && plansza[i + 2][j] == ' ' && plansza[i + 3][j] == 'c') {
						plansza[i][j] = ' ';
						plansza[i + 3][j] = 'b';
						wykonanoRuch = true;
						moznaZbic = true;  
						break;
					}
				}
			}
			if (wykonanoRuch) {
				break;  
			}
		}
		//koniec tury
		if (wykonanoRuch && moznaZbic) {
			break;  
		}
		//Losujemy ruch dla pionka i ruszamy go jesli mozemy 
		if (!moznaZbic) {
			for (int i = 0; i < plansza_wiersze; i++) {
				for (int j = 0; j < plansza_kolumny; j++) {
					if (plansza[i][j] == 'b') {  

						int kierunek = rand() % 4; 

						// Ruch w prawo
						if (kierunek == 3 && j + 1 < plansza_kolumny) {
							if (plansza[i][j + 1] == ' ') {
								plansza[i][j + 1] = 'b';
								plansza[i][j] = ' ';
								wykonanoRuch = true;
								break;
							}
						}
						// Ruch w lewo
						else if (kierunek == 2 && j - 1 >= 0) {
							if (plansza[i][j - 1] == ' ') {
								plansza[i][j - 1] = 'b';
								plansza[i][j] = ' ';
								wykonanoRuch = true;
								break;
							}
						}
						// Ruch w góre
						else if (kierunek == 0 && i - 1 >= 0) {
							if (plansza[i - 1][j] == ' ') {
								plansza[i - 1][j] = 'b';
								plansza[i][j] = ' ';
								wykonanoRuch = true;
								break;
							}
						}
						// Ruch w dół
						else if (kierunek == 1 && i + 1 < plansza_wiersze) {
							if (plansza[i + 1][j] == ' ') {
								plansza[i + 1][j] = 'b';
								plansza[i][j] = ' ';
								wykonanoRuch = true;
								break;
							}
						}
					}
				}
				if (wykonanoRuch) {
					break; 
				}
			}
		}
	}
}
void ruchGracza(Pozycje& pozycje, char plansza[plansza_wiersze][plansza_kolumny], char pionek) {
	pobierzPozycje(pozycje, plansza, 'c');
	podajRuch(pozycje);  

	int pocz_x = pozycje.poz_poczX - 'a';  
	int pocz_y = 4 - pozycje.poz_poczY;

	int ruch_x = pozycje.poz_konX - 'a';
	int ruch_y = 4 - pozycje.poz_konY;

	bool bicie = wykonajBicie(pocz_x, pocz_y, ruch_x, ruch_y, plansza, 'c');
	if (bicie) {
		return;  
	}
	if (wygranaZablokowanie(pocz_x, pocz_y, ruch_x, ruch_y, plansza, pionek)) {
		system("cls");
		char przeciwnik;
		if (pionek == 'b') {
			przeciwnik = 'c';
		}
		else {
			przeciwnik = 'b';
		}
		cout << "Gracz " << przeciwnik << " jest zablokowany" << endl;
		cout << "WYGRANA " << pionek;
		exit(0);
	}
	int roznica_x = abs(ruch_x - pocz_x);
	int roznica_y = abs(ruch_y - pocz_y);

	if (roznica_x <= 1 && roznica_y <= 1) {
		zwyklyRuch(pocz_x, pocz_y, ruch_x, ruch_y, plansza, 'c');
	}
	else {
		cout << "Nie mozesz sie ruszac o dwa pola do przodu!" << endl;
		ruchGracza(pozycje, plansza, 'c');
	}
}
void zmienTure(Gracze& gracze) {
	gracze.tura = !gracze.tura;
}

int main() {
	setlocale(LC_ALL, "en_US.UTF-8");
	int trybgry;
	cout << "WYBIERZ TRYB GRY \n";
	cout << "1VS1 = WYBIERZ 1  \n";
	cout << "TY VS BOT = WYBIERZ 2  \n";
	cin >> trybgry;

	char plansza[plansza_wiersze][plansza_kolumny];
	Pozycje pozycje;
	int licznikc = 0;
	int licznikb = 0;
	Gracze gracze = {};

	if (trybgry == 1) {
		wczytajGraczy(gracze);
		system("cls");
		wypiszGraczy(gracze);

		wygladPlanszy(plansza);
		wyswietlPlansze(plansza);

		cout << endl;
		while (true) {
			char pionek;
			if (gracze.tura) {
				pionek = 'b';
			}
			else {
				pionek = 'c';
			}
			if (gracze.tura) {
				cout << endl << "Imie gracza : " << gracze.gracz_bialy << endl << "Tura bialych " << endl;
			}
			else {
				cout << endl << "Imie gracza : " << gracze.gracz_czarny << endl << "Tura czarnych " << endl;
			}

			cout << endl;
			pobierzPozycje(pozycje, plansza, pionek);
			podajRuch(pozycje);
			cout << endl;
			if (gracze.tura) {
				wykonajRuch(pozycje, plansza, pionek);
			}
			else {
				wykonajRuch(pozycje, plansza, pionek);
			}
			wyswietlPlansze(plansza);
			zmienTure(gracze);

			if (wygrana(plansza, licznikc, licznikb)) {
				if (licznikc == 0) {
					system("cls");
					cout << "WYGRANA CZARNYCH";
					exit(0);
				}
				else if (licznikb == 0) {
					system("cls");
					cout << "WYGRANA BIALYCH";
					exit(0);
				}
			}

			system("cls");
			wyswietlPlansze(plansza);
		}
		cout << endl << "Czas rozgrywki się skończył!" << endl;
	}
	else if (trybgry == 2) {
		char pionek;
		if (gracze.tura) {
			pionek = 'c';
		}
		else {
			pionek = 'b';
		}
		wczytajGraczy(gracze);
		system("cls");
		wypiszGraczy(gracze);

		wygladPlanszy(plansza);
		wyswietlPlansze(plansza);

		cout << endl;
		while (true) {
			if (gracze.tura) {
				obslugaBota(pozycje, plansza);
			}
			else {
				cout << "Tura gracza " << gracze.gracz_czarny <<endl<< " Tura czarnych :" << endl;
				ruchGracza(pozycje, plansza, pionek);
			}
			zmienTure(gracze);
			system("cls");
			wyswietlPlansze(plansza);
			cout << endl;

			if (wygrana(plansza, licznikc, licznikb)) {
				system("cls");
				if (licznikc == 0) {
					cout << "WYGRANA CZARNYCH";
					exit(0);
				}
				else if (licznikb == 0) {
					cout << "WYGRANA BIALYCH";
					exit(0);
				}
			}
		}
	}
	else {
		cout << "Zla wartosc";
	}
}